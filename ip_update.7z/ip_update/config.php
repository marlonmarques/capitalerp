<?php
$soap_location = 'https://192.168.1.77:8080/remote/index.php';
$soap_uri = 'https://192.168.1.77:8080/remote/';
$soap_user = 'ipupdate';
$soap_password = 'fcn!UT7Z2t';